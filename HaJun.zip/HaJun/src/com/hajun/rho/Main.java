package com.hajun.rho;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JToolBar;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTabbedPane;
import javax.swing.JButton;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.image.ImageProducer;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JCheckBox;
import java.awt.GridBagLayout;
import javax.swing.JTable;
import java.awt.GridBagConstraints;
import javax.swing.JEditorPane;
import java.awt.Canvas;
import java.awt.Panel;
import javax.swing.JList;
import javax.swing.JCheckBoxMenuItem;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import java.awt.Choice;
import javax.swing.border.LineBorder;
import javax.swing.event.TableColumnModelListener;

import java.awt.Color;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import java.awt.Component;

public class Main extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTable table;
	private JTable table_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main() {
		setTitle("하준이 생활 분석 프로그램");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 944, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));

		JPanel panel = new JPanel();
		contentPane.add(panel);
		panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		panel.add(tabbedPane);

		// ----- 소개 탭
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("소개", null, panel_1, null);
		panel_1.setLayout(null);

		// ----- /소개 탭

		// ----- 기록보기 탭
		JPanel panel_2 = new JPanel();
		tabbedPane.addTab("기록보기", null, panel_2, null);

		String[] viewHeader = { "일자", "시간", "모유", "분유", "소변", "대변", "목욕", "크림", "비고" };
		String[][] viewContents = { { "일자", "시간", "모유", "분유", "소변", "대변", "목욕", "크림", "비고" } };
		table = new JTable(viewContents, viewHeader);
		table.setShowGrid(false);
		table.setBorder(null);
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setEnabled(false);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_NEXT_COLUMN);
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setViewportBorder(null);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		panel_2.add(scrollPane);
		// ----- /기록보기 탭

		// ----- 차트 탭
		JPanel panel_3 = new JPanel();
		tabbedPane.addTab("차트", null, panel_3, null);
		// ----- /차트 탭

		// ----- 데이터 분석 탭
		JPanel panel_4 = new JPanel();
		tabbedPane.addTab("데이터 분석", null, panel_4, null);
		// ----- /데이터 분석 탭

		// ----- 기록하기 탭
		JPanel panel_5 = new JPanel();
		tabbedPane.addTab("기록하기", null, panel_5, null);

		String[] recordHeader = { "일자", "시간", "모유", "분유", "소변", "대변", "목욕", "크림", "비고" };
		String[][] recordContents = { { "일자", "시간", "모유", "분유", "소변", "대변", "목욕", "크림", "비고" } };
		
		table_1 = new JTable(recordContents, recordHeader);
		table_1.setShowGrid(false);
		table_1.setBorder(null);
		table_1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table_1.setEnabled(false);
		table_1.setAutoResizeMode(JTable.AUTO_RESIZE_NEXT_COLUMN);
		
		JScrollPane scrollPane_1 = new JScrollPane(table_1);
		scrollPane_1.setViewportBorder(null);
		scrollPane_1.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		panel_5.add(scrollPane_1);
		// ----- /기록하기 탭
	}
}
